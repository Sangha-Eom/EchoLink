rootProject.name = "auth-server"
