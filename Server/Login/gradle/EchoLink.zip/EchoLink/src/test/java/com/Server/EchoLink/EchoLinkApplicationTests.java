package com.Server.EchoLink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EchoLinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
